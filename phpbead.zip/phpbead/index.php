<?php 
require_once("utils/init.php");
require_once("partials/header.php");

?>

<div class="introduction">
    <h1 class="header">Welcome to monkey votes!</h1>

    <p class="paragraph">Here you can choose from any of polls and give us your very important opinion. Select a poll and choose wisely.</p>
</div>

<?php require("active.php"); ?>
<?php require("expired.php"); ?>

<?php require("partials/messages.php"); ?>

<?php require("partials/footer.php"); ?>